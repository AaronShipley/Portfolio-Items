/*
 * Calculator.cpp
 *
 *  Date: [05/15/2021]
 *  Author: [Aaron Shipley]
 */

#include <iostream>

using namespace std;

int main() // convert from void to int so main will return int
{
    char statement[100];
    double op1, op2; //changed to double to get proper mathematical equations 
    char operation;
    char answer = 'Y'; // forgot semicolon at end of line
    while (answer == 'Y' || answer == 'y') {
        cout << "Enter expression" << endl;
        cin >> op1 >> operation >> op2;
        if (operation == '+') // changed from double quotation marks to single
            cout << op1 << " + " << op2 << " = " << op1 + op2 << endl; //chnaged >> to << to match for output
        if (operation == '-')
            cout << op1 << " - " << op2 << " = " << op1 - op2 << endl; // >> changed to << to match for output
        if (operation == '*')
            cout << op1 << " * " << op2 << " = " << op1 * op2 << endl; //here ; added to show end of line
            //changed from division to multiplication in output statement
        if (operation == '/')
            cout << op1 << " / " << op2 << " = " << op1 / op2 << endl;
                        //changed from multiplication to division symbol in output statement
        cout << "Do you wish to evaluate another expression? " << endl;
        cin >> answer;
        if (answer == ('N') || answer == ('n')) { //added if statement for 'n' or 'N' option
            cout << "Program Finished" << endl; // added output statement from if statement
        }
    }
    return 0; // return statement added 
}
