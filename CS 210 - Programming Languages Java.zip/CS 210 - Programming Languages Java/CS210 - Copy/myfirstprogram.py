import re
import string

def printsomething():
    print("Hello my name is Aaron Shipley")