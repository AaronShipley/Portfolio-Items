#Aaron Shipley

def game_instructions():
    # Print a main menu and commands for player
    print('\nWelcome to Guitar Builder. A text based adventure game.\n')
    print('Collect 6 parts to build a custom guitar for the customer or lose their business.\n')
    print('Move Commands: North , South, East, West. Remember to capitalize your direction.\n')
    print('Add to Inventory: type "get" and then the item name.\n')
    print('When you have collected all 6 parts, go to the showroom and WIN THE GAME!!!')



def main():
    # define an inventory that starts out as empty
    # define a dictionary linking a room to other rooms
    # define the text output when entering a room

    rooms = {
        'Assembly Room': { 'name' : 'Assembly Room', 'South' : 'Electronics Repair Room' ,'North': 'Back Office',
                          'West':'Basement', 'East' : 'Behind the Counter'
                          , 'text' : 'You are in the Assembly Room.'},
        'Electronics Repair Room': {'name': 'Electronics Repair Room', 'North': 'Assembly Room',
                                    'East': 'Wood Shop', 'item':'pickups',
                                    'text': 'You are in the Electronics Repair Room.'},
        'Wood Shop': {'name': 'Wood Shop', 'West': 'Electronics Repair Room','item':'body',
                      'text':'You are in the Wood shop.'},
        'Basement':{'name': ' Basement', 'East':'Assembly Room','item':'neck'
                   ,'text':'You are in the basement.'},
        "Back Office":{'name':'Back Office','South':'Assembly Room','East':'Backroom Closet','item':'head'
                       ,'text': 'You are in the back office.'},
        'Backroom Closet':{'name':'Backroom Closet','West':'Back Office','item':'tuning knobs'
                           ,'text':'You are in the backroom closet.'},
        'Behind the Counter':{'name':'Behind the Counter','West':'Assembly Room','North':'Showroom'
                              ,'item':'strings','text':'You are behind the counter.'},
        'Showroom':{'name':'Showroom','South':'Behind the Counter'}
        }

    item_list ={'get head','get neck','get tuning knobs','get body','get strings','get pickups'}

    #Show player game instructions
    print(game_instructions())

    key_word = 'get'
    move_directions = ['North', 'South', 'East', 'West']
    current_room = rooms['Assembly Room']  ## Starting room for the game
    inventory=[]

    while True:
        # displays current room to the player
        if 'item' not in current_room:
            print('You are in the {}.\n'.format(current_room['name']))
            print(inventory)
        else:
            print('You are in the {}. You see a {}\n'.format(current_room['name'],current_room['item']))
            print(inventory)
            gear = input('\nWhat do you want to do with the {}?'.format(current_room['item']))
            gear1 = gear.split()

            # Conditional to add items to inventory
            if gear1[0]== key_word and gear1[1] in current_room['item']:
                inventory.append(current_room['item'])
                print('You Collected the {}'.format(current_room['item']))
                del (current_room['item'])
            elif gear == 'Exit':  ## How to exit the game from this prompt
                print('You have exited the game. Thank you for playing.')
                break
            else:
                print('You did not collect the item.')

        # getting commands from the player
        command = input('\nWhat direction do you want to go?')

        # Player will input what direction they want to go
        # input for movement
        if command in move_directions:
            if command in current_room:
                current_room = rooms[current_room[command]]
                # conditional if player enters the showroom
                if current_room == rooms['Showroom']:
                    # factor to identify if inventory is full or not to finish game
                    if len(inventory)== 6:
                        #You win the game
                        print('You have collected all parts and built the guitar!\n',
                              'The customer is happy!!! You win the Game!!!!')
                        break
                    else:
                        # you lose the game
                        print('You entered the showroom.The guitar is incomplete.\n',
                              'The customer is mad! Game Over')
                        break
            else:
                # incorrect movement
                print('You cannot go that direction.')
        # How to exit the game
        elif command == 'Exit':
            print('You have exited the game. Thank you for playing.')
            break
        # Bad command
        else:
            print('Invalid Input.')
main()




