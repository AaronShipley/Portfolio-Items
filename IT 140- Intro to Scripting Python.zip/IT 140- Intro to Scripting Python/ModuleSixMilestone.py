# Aaron Shipley

#A dictionary for the simplified Guitar Builder text game
#The dictionary links a room to other rooms.
# Dictionary has been modified from one provided to fit code I have written and structure of my game.
rooms = {
        'Assembly Room': {'name':'Assembly Room','South': 'Electronics Repair Room',
                          'text': 'You are in the Assembly Room.'},
        'Electronics Repair Room': {'name':'Electronics Repair Room', 'North': 'Assembly Room',
                                    'East': 'Wood Shop', 'text': 'You are in the Electronics Repair Room.'},
        'Wood Shop': {'name':'Wood Shop', 'West': 'Electronics Repair Room'}
    }
#Data input for directions to move
move_directions = ['North','South','East','West']
current_room = rooms['Assembly Room'] ## Starting room for the game

#introduction and directions on what to input to move for player
print('Choose a direction from the list when prompted.\n Capitalize the direction when entering.',move_directions)
print('To end the game, type "Exit".')

while True:
    #displays current room to the player
    print('\nYou are in the {}.'.format(current_room['name']))
    # getting commands from the player
    command = input('\nWhat direction do you want to go?') ## Player will input what direction they want to go
    #input for movement
    if command in move_directions:
        if command in current_room:
            current_room = rooms[current_room[command]]
        else:
            #incorrect movement
            print('You cannot go that direction.')
    # How to exit the game
    elif command == 'Exit':
        print('\nYou have exited the game. Thank you for playing.')
        break
     #Bad command
    else:
        print('Invalid Input.')


