
import random

user_name = input('Welcome to the Higher / Lower game!')
lower = int(input('Enter lower bound number.'))  # lowest range number
upper = int(input('Enter upper bound number.'))  # highest range number
selection = random.randint(lower , upper)
guess = int(input('Guess a number')
if guess < selection:
    print('Too low. Guess again.')

elif guess > selection:
    print('Too high. Guess again.')
elif guess == selection:
    print('you got it!')

