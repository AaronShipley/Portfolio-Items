

name = input('What is your name?:')  # name input is person's first name
age = int(input('How old are you?:'))  # input inserts person's age

cur_year: int = 2021

birth_date = cur_year - age
# birth_date calculated from subtracting age from the current year in the input

print('Hello', name+'!', 'You were born in', birth_date)
