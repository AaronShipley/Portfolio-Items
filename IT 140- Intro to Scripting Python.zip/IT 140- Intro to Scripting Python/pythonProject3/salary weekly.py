wage = float(input('Enter the wage:'))  # the amount per hour an employee earns
regularHours = float(input('Enter the regular hours:'))  # Regular hours is up to 40 hours per week
overtimeHours = float(input('Enter the overtime hours:'))  # Overtime hours is any hours above 40 per week
total_pay1 = (wage * regularHours)
total_pay2 = (wage * regularHours) + (wage * overtimeHours) * 1.5

if (regularHours <= 40) and (overtimeHours == 0):
    print('Total Pay:', total_pay1)
elif (regularHours == 40) and (overtimeHours > 0):
    print('Total Pay:', total_pay2)
