

name = input('What is your name?:')  # name input is person's first name
age = int(input('How old are you?:'))  # input inserts person's age

cur_year = int(input())
birth_date = cur_year - age

print('Hello', name+'!', 'You were born in', birth_date)
